const p = document.querySelector('p');
console.log('im in another file');
console.log(p);
