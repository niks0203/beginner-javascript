const name = 'Neekee';
const hello = `hello my name is ${name}.
 Nice to meet you`;
